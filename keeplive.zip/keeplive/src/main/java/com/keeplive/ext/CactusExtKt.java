package com.keeplive.ext;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.keeplive.account.AccountHelper;
import com.keeplive.act.LockScreenActivity;
import com.keeplive.act.OnePixActivity;
import com.keeplive.service.CactusJobService;
import com.keeplive.service.HideNotifyService;
import com.keeplive.service.LocalService;
import com.keeplive.service.RemoteService;
import com.keeplive.workmanager.CactusWorker;

import java.lang.ref.WeakReference;
import java.util.concurrent.TimeUnit;

import static android.content.Context.ACTIVITY_SERVICE;

public class CactusExtKt {
    public static final boolean musicEnable=true;//播放无声音乐么
    public static final boolean hidenotify=false;//取消前台通知么
    public static final String REMOTESERVICEPRO="HKLive";//远程服务进程名字
    private static WeakReference<Activity> mWeakReference;
    public static Handler mHandler = new Handler(Looper.getMainLooper());

    //启动开始 保活
    public static final void registerKL(Context context) {
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                startJobCactus(context);
            } else {
                startLocalService(context);
                registerWorker(context);
            }
            AccountHelper.addAccount(context);//添加账户
            AccountHelper.autoSyncAccount();//调用告知系统自动同步
        } catch (Exception e) {

        }
    }

    //如果保活程序没运行 那就去运行吧
    public static boolean isKeepLiveRunning(final Context context){
        boolean isLocalServiceWork = CactusExtKt.isRunService(context,LocalService.class.getName());
        boolean isRemoteServiceWork = CactusExtKt.isRunningTaskExist(context,REMOTESERVICEPRO);
        if(isLocalServiceWork&&isRemoteServiceWork){
            return true;
        }
        return false;
    }

    public static final void setOnePix(OnePixActivity activity) {
        if (mWeakReference == null) {
            mWeakReference = new WeakReference(activity);
        }
    }

    public static void openOnePix(final Context context){
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startOnePixActivity(context);
            }
        }, 1000);
    }

    public static void openLockScreenAct(final Context context){
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(Intent.ACTION_MAIN, null);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION | Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setClass(context, LockScreenActivity.class);
                context.startActivity(intent);
            }
        }, 1200);
    }

    public static final void startOnePixActivity(Context context) {
        if (!isScreenOn(context) && Build.VERSION.SDK_INT < 28) {
            Intent onePixIntent = new Intent(context, OnePixActivity.class);
            onePixIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            onePixIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                finishOnePix();
                PendingIntent.getActivity(context, 0, onePixIntent, 0).send();
            } catch (Exception e) {
            }
        }
    }

    public static final void finishOnePix() {
        try {
            WeakReference weakReference = mWeakReference;
            if (weakReference != null) {
                Activity activity = (Activity) weakReference.get();
                if (activity != null) {
                    activity.finish();
                }
                mWeakReference = null;
            }
        }catch (Exception e){
        }
    }

    public static boolean isScreenOn(Context context) {
        boolean isScreenOn;
        try {
            //检查屏幕是否点亮
            PowerManager pm = (PowerManager) context.getApplicationContext().getSystemService(Context.POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
                isScreenOn = pm.isInteractive();
            }else {
                isScreenOn = pm.isScreenOn();
            }
            return isScreenOn;
        } catch (Exception e) {
            isScreenOn = false;
        }
        return isScreenOn;
    }


    //启动远程服务
    public static final Intent startRemoteService(Context context) {
        Intent intent = new Intent(context, RemoteService.class);
        startInternService(context, intent);
        return intent;
    }
    //启动本地服务
    public static final Intent startLocalService(Context context) {
        Intent intent = new Intent(context, LocalService.class);
        startInternService(context, intent);
        return intent;
    }

    //启动取消状态栏通知服务
    public static final Intent startHideNotyService(Context context) {
        Intent intent = new Intent(context, HideNotifyService.class);
        startInternService(context, intent);
        return intent;
    }

    //开启JobService服务
    public static final void startJobCactus(Context context) {
        Intent intent = new Intent(context, CactusJobService.class);
        startInternService(context, intent);
    }

    //8.0启动服务方式
    public static final void startInternService(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    //状态栏通知
    public static void startForegroundNt(Service context){
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN_MR2) {
            context.startForeground(NotificationHP.NOTICE_ID, NotificationHP.getInstance().getNotification(context));//通知栏显示
            if(hidenotify){
                startHideNotyService(context);
            }
        }else {
            context.startForeground(NotificationHP.NOTICE_ID, new Notification());//通知栏不显示
        }
    }

    //开启workmanager
    public static void registerWorker(Context context){
        try {
            PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(CactusWorker.class,5, TimeUnit.SECONDS).build();
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    CactusWorker.class.getName(),
                    ExistingPeriodicWorkPolicy.REPLACE,workRequest);
        }catch (Exception e){
            unregisterWorker(context);
        }
    }

    /**
     * 取消WorkManager
     *
     * @receiver Context
     * @return Operation
     */

    public static void unregisterWorker(Context context){
        WorkManager.getInstance(context).cancelUniqueWork(CactusWorker.class.getName());
    }


    /**
     * 判断服务是否在运行
     * 服务名称为全路径 例如com.ghost.WidgetUpdateService
     */
    public static boolean isRunService(Context context,String serviceName) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceName.equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断服务进程是否在运行
     * @return Boolean
     */
    public static boolean isRunningTaskExist(Context context,String processName) {
        ActivityManager manager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        processName = context.getPackageName()+":"+processName;//服务进程 packegeName:RemoteName
        for (ActivityManager.RunningAppProcessInfo processInfo : manager.getRunningAppProcesses()) {
            if (processName.equals(processInfo.processName)) {
                return true;
            }
        }
        return false;
    }

}
