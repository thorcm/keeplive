package com.keeplive.ext;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.keeplive.R;

public class NotificationHP {
    /**Build.VERSION.SDK_INT<18 直接 new Notification()
     *
     * Build.VERSION.SDK_INT>18  其中>=26 new Notification.Builder(context,CHANNEL_ID) 还要createNotificationChannel(channel)
     * 取消通知： notManager.deleteNotificationChannel(CHANNEL_ID);
     * <26 new Notification.Builder(context)，取消通知： NotificationManager.cancel(NOTICE_ID);
     */

    private static final String CHANNEL_ID="appid";   //通道渠道id
    public static final String  CHANEL_NAME="全民反诈"; //通道渠道名称
    public static final int NOTICE_ID=110;//通知id

    private static NotificationHP notificat = new NotificationHP();
    private NotificationManager notManager;
    private Notification notification;

    public static synchronized NotificationHP getInstance(){
        return notificat;
    }

    //前台通知 显示自定义通知内容
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public Notification getNotification(Context context){
        if(notification!=null){
            return notification;
        }
        notManager=(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder builder;
        //获取Notification实例   获取Notification实例有很多方法处理
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            //向上兼容 用Notification.Builder构造notification对象
            builder = new Notification.Builder(context,CHANNEL_ID);
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel.enableLights(false);//是否在桌面icon右上角展示小红点
            channel.setLightColor(Color.GREEN);//小红点颜色
            channel.setShowBadge(false); //是否在久按桌面图标时显示此渠道的通知
            notManager.createNotificationChannel(channel);
        }else {
            builder = new Notification.Builder(context);
            //向下兼容 用NotificationCompat.Builder构造notification对象
//            Intent intent = new Intent(this, NotificationActivity.class);
//            PendingIntent pIntent = PendingIntent.getActivity(this, 1, intent, 0);
//            setContentIntent(pIntent);
        }
         notification = builder
                .setContentTitle("全民反诈")
                .setContentText("打击防范网络诈骗")
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_launcher)//状态栏图标
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),R.drawable.ic_launcher))//通知栏图标
                .setTicker("全民反诈")
                .setAutoCancel(false)//完成跳转自动取消通知
                .build();
        //发送通知
        notManager.notify(NOTICE_ID,notification);

        return notification;
    }

    //取消通知栏信息 oom_adj 值不变
    public void cancleNotify(){
        if(notManager!=null){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notManager.deleteNotificationChannel(CHANNEL_ID);
            }
            notManager.cancel(NOTICE_ID);
        }
    }

}
