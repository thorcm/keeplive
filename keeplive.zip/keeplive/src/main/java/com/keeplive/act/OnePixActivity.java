package com.keeplive.act;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.Nullable;

import com.keeplive.ext.CactusExtKt;

//华为6.0就失效，因广播被取消了
public class OnePixActivity extends Activity {
    /* Access modifiers changed, original: protected */
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);
        Window window = getWindow();
        window.setGravity(Gravity.LEFT | Gravity.TOP);
        WindowManager.LayoutParams winAtt = window.getAttributes();
        winAtt.x = 0;
        winAtt.y = 0;
        winAtt.height = 1;
        winAtt.width = 1;
        window.setAttributes(winAtt);
        CactusExtKt.setOnePix(this);
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        if (CactusExtKt.isScreenOn(this)) {
            finish();
        }
    }


    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}