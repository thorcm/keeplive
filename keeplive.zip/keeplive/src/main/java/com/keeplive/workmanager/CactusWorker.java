package com.keeplive.workmanager;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.keeplive.ext.CactusExtKt;
import com.keeplive.service.CactusJobService;
import com.keeplive.service.LocalService;
import com.keeplive.service.RemoteService;

public class CactusWorker extends Worker {

    private Context context;

    public CactusWorker(Context context, WorkerParameters workerParams) {
        super(context, workerParams);
        this.context = context;
    }

    //拉活
    public Result doWork() {
        if(!CactusExtKt.isKeepLiveRunning(context)&&!isStopped()){
            //启动job服务
            CactusExtKt.startJobCactus(context);
            //启动相互绑定的服务
            CactusExtKt.startLocalService(context);
        }
        return Result.success();
    }
}