package com.keeplive.workmanager;

public class Readme {

/*
 1.双进程守护方案，华为6.0就失效

2.监听锁屏/亮屏/解锁广播，打开1像素Activity，华为6.0就失效，因广播被取消了

3.故意在后台播放无声的音乐，华为M10手机9.0失效

4.使用JobScheduler唤醒Service，7.0以上失效

5.集成华为/小米/oppo/vivo/魅族等push，因为项目本地化部署，不适合

6.推送互相唤醒复活：极光、友盟、以及各大厂商的推送，

7.同派系APP广播互相唤醒：比如今日头条系、阿里系，

8.使用自定义锁屏界面：覆盖了系统锁屏界面。网易云音乐就是如此，但是会生成一个常驻通知栏的通知

9.把APP设置为系统应用，不适合，因为需要权限等

10.native进程(已报废)

11.利用账号同步机制拉活,失效了

12. 提高Service优先级，比如onStartCommand返回START_STICKY，没什么效果

为什么保活失败？

答：因为点击home键使app长时间停留在后台，内存不足被kill；

进入锁屏状态一段时间，省电机制会kill后台进程。
————————————————
    原文链接：https://blog.csdn.net/u012482178/article/details/95218872*/
}
